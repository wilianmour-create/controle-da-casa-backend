# Backend - Controle da Casa

Backend simples para salvar o Controle da Casa na nuvem e acessar de qualquer dispositivo com login do Google.

## O que ele faz
- `GET /api/state?user_id=...` -> retorna o save do usuário
- `POST /api/state` -> salva o estado (meses, extras, casal/Jojo, parcelamentos, troféus, coins)
- Auth: o frontend manda o `user_id` = email do Google (depois de login). Nesta versão simples, sem validação de token no servidor — ideal para uso pessoal. Para produção, valide o ID token do Google no backend.

## Como rodar em 5 minutos (opção gratuita - Render / Railway)
1. Crie conta no Render.com (grátis)
2. New Web Service -> conecte este repositório / suba estes arquivos
3. Build: `npm install` | Start: `npm start`
4. Copie a URL gerada (ex: https://controle-da-casa-backend.onrender.com)
5. No app, clique em ⚙️ Backend -> cole a URL -> clique em Conectar

## Estrutura
- server.js - API Express + persistência em JSON (data.json) + CORS
- Para escalar, troque `data.json` por Supabase / Postgres — o formato do save é o mesmo.

## Formato do save
O mesmo JSON que o app já exporta como backup: { meses, extras, casal, parcelamentos, trofeus, coins, updatedAt }
