# Como o app conecta no backend
No app, em ⚙️ Backend:
- Cole a URL do backend (ex: https://controle-da-casa-backend.onrender.com)
- Clique em Conectar -> o app faz GET /api/state?user_id=seu-email
- Ao salvar, faz POST /api/state com { user_id, state }
- Se o backend estiver offline, o app continua com localStorage e mostra "Backend offline — usando save local"
