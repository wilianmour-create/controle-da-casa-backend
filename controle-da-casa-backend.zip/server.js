const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
const DB_FILE = path.join(__dirname, 'data.json');
function readDB(){ try{ return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); }catch{ return {}; } }
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
app.get('/', (req,res)=> res.json({ ok:true, service:'Controle da Casa Backend', endpoints:['GET /api/state?user_id=','POST /api/state'] }));
app.get('/api/state', (req,res)=>{
  const user_id = req.query.user_id;
  if(!user_id) return res.status(400).json({ error:'user_id é obrigatório' });
  const db = readDB();
  if(!db[user_id]) return res.json({ found:false, state:null });
  res.json({ found:true, state: db[user_id] });
});
app.post('/api/state', (req,res)=>{
  const { user_id, state } = req.body || {};
  if(!user_id || !state) return res.status(400).json({ error:'user_id e state são obrigatórios' });
  const db = readDB();
  db[user_id] = { ...state, updatedAt: new Date().toISOString(), user_id };
  writeDB(db);
  res.json({ ok:true, updatedAt: db[user_id].updatedAt });
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Controle da Casa backend rodando na porta '+PORT));
